# Statistics-for-Data-Science
Please find my submission for the coursera course: "Statistics for Data Science with Python", my work email is henry.battley@ibm.com

Please regard all answers as they are in the order of how they are asked
